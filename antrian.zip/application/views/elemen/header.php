<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <span class="navbar-brand">Besukan Online Rumah Tahanan Samarinda</span>
    </div>
  </div><!-- /.container-fluid -->
</nav>