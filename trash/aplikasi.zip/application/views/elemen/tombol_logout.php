<br>
<br>
<p class="text-center">
	<a href="<?= base_url() ?>index.php/login/logout">logout</a>
</p>