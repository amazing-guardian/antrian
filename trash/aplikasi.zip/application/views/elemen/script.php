<script type="text/javascript">
	<?php
		$this->load->view('skrip/jquery.min.js');
	?>
</script>